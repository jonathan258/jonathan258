package info.hccis.wills.services.entity;

import info.hccis.util.CisUtility;

/**
 * Represents a customer
 *
 * @author bjmac
 * @since 8-Jun-2021
 */
public class Customer {

    private String firstName;
    private String lastName;
    public static final int TYPE_REGULAR =0;
    public static final int TYPE_PREFERRED = 1;
    public static final int TYPE_SENIOR = 2;

    public Customer() {
    }

    /**
     * Constructor that accepts first and last name as one string
     *
     * @since 20210608
     * @author BJM
     */
    public Customer(String name) {
        setFirstAndLastName(name);
    }

    public Customer(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * Method to return the discount rate appropriate for this customer based on
     * the type.
     *
     * @return
     * @since 20210608
     * @author BJM
     */
    public double getDiscountRate() {
        double discount = 0;
        return discount;
    }

    /**
     * Get the description based on the customer type
     *
     * @return
     * @since 20210608
     * @author BJM
     */
    public String getCustomerTypeDescription() {
        String description = "Regular";

        return description;
    }

    /**
     * Get the first and last name out of the one string.Note that it is
     * expected to have exactly two parts. Note also that it is called from the
     * constructor which is why it is set to final (We'll get to this in
     * inheritance. It will work without final but give a warning.
     *
     * @param name Full name (first and last separated by space)
     * @since 20210608
     * @author BJM
     */
    public final void setFirstAndLastName(String name) {
        String[] parts = name.split(" ");
        if (parts.length >= 2) {
            firstName = parts[0];
            lastName = parts[1];
        }
    }

    public void getInformation() {
        this.firstName = CisUtility.getInputString("First Name?");
        this.lastName = CisUtility.getInputString("Last Name?");

    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void display() {
        CisUtility.display(this.toString());
    }

    @Override
    public String toString() {
        String output = "Name: " + firstName + " " + lastName + " Customer Type: " + getCustomerTypeDescription();
        return output;
    }
}
